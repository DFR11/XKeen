# Importing configuration modules
	
# Configuration module
. "$xinstall_dir/08_install_configs/01_configs_install.sh"

# Configuration templates
. "$xinstall_dir/08_install_configs/02_configs_dir"