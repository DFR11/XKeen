# Импорт модулей конфигураций
	
# Модуль конфигурации
. "$xinstall_dir/08_install_configs/01_configs_install.sh"

# Шаблоны конфигурации
. "$xinstall_dir/08_install_configs/02_configs_dir"