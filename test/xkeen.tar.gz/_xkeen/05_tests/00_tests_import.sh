# Импорт модулей тестирования

# Модули тестирования
. "$xtests_dir/01_tests_connected.sh"
. "$xtests_dir/02_tests_xports.sh"
. "$xtests_dir/03_tests_storage.sh"