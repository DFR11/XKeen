# Импорт модулей проверки версий

# Модули проверки версий
. "$xinfo_dir/08_info_version/01_version_xkeen.sh"
. "$xinfo_dir/08_info_version/02_version_mihomo.sh"
. "$xinfo_dir/08_info_version/02_version_xray.sh"