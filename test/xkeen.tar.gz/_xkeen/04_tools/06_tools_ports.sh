data_is_updated_donor() {
    file=$1
    new_ports=$2
    current_ports=$(
        awk -F= '/^port_donor/{print $2; exit}' "$file" \
        | tr -d '"'
    )
    if [ "$current_ports" = "$new_ports" ]; then
        return 0
    else
        return 1
    fi
}

data_is_updated_excluded() {
    file=$1
    new_ports=$2
    current_ports=$(
        awk -F= '/^port_exclude/{print $2; exit}' "$file" \
        | tr -d '"'
    )
    if [ "$current_ports" = "$new_ports" ]; then
        return 0
    else
        return 1
    fi
}

normalize_ports() {
    input="$1"
    tmpfile=$(mktemp)

    # Separate the input data by commas and process it line by line
    echo "$input" | tr ',' '\n' | while read port; do
        # Removing spaces
        port=$(echo "$port" | tr -d '[:space:]')

        # Checking if the port is a range
        if echo "$port" | grep -q '[:-]'; then
            # Replaceable '-' with ':'
            port=$(echo "$port" | tr '-' ':')
            # Extracting the beginning and end of the range
            start=$(echo "$port" | cut -d':' -f1)
            end=$(echo "$port" | cut -d':' -f2)

            # We check that start and end are numbers and do not exceed 65535
            if ! [ "$start" -ge 0 ] 2>/dev/null || ! [ "$end" -ge 0 ] 2>/dev/null || \
               [ "$start" -gt 65535 ] || [ "$end" -gt 65535 ]; then
                continue
            fi

            # If the first number is greater than the second, swap them
            if [ "$start" -gt "$end" ]; then
                temp="$start"
                start="$end"
                end="$temp"
            fi

            # We form a range in the start:end format
            normalized_port="$start:$end"
        else
            # If this is a single port, check that this number does not exceed 65535
            if ! [ "$port" -ge 0 ] 2>/dev/null || [ "$port" -gt 65535 ]; then
                continue
            fi
            normalized_port="$port"
        fi

        # Adding a normalized port to the temporary file
        echo "$normalized_port" >> "$tmpfile"
    done

    # Reading the result from a temporary file, sorting and removing duplicates
    if [ -s "$tmpfile" ]; then
        sort -n -u "$tmpfile" | tr '\n' ',' | sed 's/,$//'
    fi

    # Deleting a temporary file
    rm -f "$tmpfile"
}

# Port Validation Function
validate_and_clean_ports() {
    input_ports="$1"
    final_ports=""

    final_ports=$(echo "$input_ports" | tr ',' '\n' | awk '
        function is_valid(p) {
            return p > 0 && p <= 65535 && p ~ /^[0-9]+$/
        }
        {
            gsub(/ /, "", $0)
            if ($0 == "") next;

            n = split($0, a, ":")
            if (n == 1) {
                if (is_valid(a[1])) print a[1]
            } else if (n == 2) {
                if (is_valid(a[1]) && is_valid(a[2]) && a[1] < a[2]) print a[1]":"a[2]
            }
        }
    ' | sort -un | tr '\n' ',' | sed 's/,$//')
    
    echo "$final_ports"
}

# Custom Port Processing Function
process_user_ports() {
    user_proxy_ports=""
    user_exclude_ports=""

    if [ -f "/opt/etc/xkeen/port_proxying.lst" ]; then
        user_proxy_ports=$(
            sed 's/\r$//' "/opt/etc/xkeen/port_proxying.lst" | \
            sed 's/^[[:space:]]*//; s/[[:space:]]*$//' | \
            grep -v '^#' | \
            grep -v '^$' | \
            sed 's/-/:/g' | \
            grep -E '^[0-9]+(:[0-9]+)?$' | \
            tr '\n' ',' | \
            sed 's/,$//'
        )
    fi

    if [ -f "/opt/etc/xkeen/port_exclude.lst" ]; then
        user_exclude_ports=$(
            sed 's/\r$//' "/opt/etc/xkeen/port_exclude.lst" | \
            sed 's/^[[:space:]]*//; s/[[:space:]]*$//' | \
            grep -v '^#' | \
            grep -v '^$' | \
            sed 's/-/:/g' | \
            grep -E '^[0-9]+(:[0-9]+)?$' | \
            tr '\n' ',' | \
            sed 's/,$//'
        )
    fi

    if [ -n "$user_proxy_ports" ]; then
        port_donor="${port_donor},${user_proxy_ports}"

        port_donor=$(validate_and_clean_ports "$port_donor")

    elif [ -n "$user_exclude_ports" ]; then
        port_exclude="${port_exclude},${user_exclude_ports}"

        port_exclude=$(validate_and_clean_ports "$port_exclude")

    else
        :
    fi
}

add_ports_donor() {
    add_ports="donor"
    choice_port_xkeen
    if [ -z "$1" ]; then
        echo -e "${red}Error${reset}: port list cannot be empty"
        return 1
    fi

    file_port_exclude="/opt/etc/xkeen/port_exclude.lst"
    excluded_ports_from_file=""
    excluded_ports_from_var=""
    conflict_found=0
    error_message=""

    if [ -f "$file_port_exclude" ]; then
        excluded_ports_from_file=$(grep -v '^#' "$file_port_exclude" | grep -v '^$' | tr -d '[:space:]')
    fi

    excluded_ports_from_var=$(
        awk -F= '/^port_exclude/{print $2; exit}' "$initd_dir/S99xkeen" \
        | tr -d '"' | tr -d '[:space:]'
    )
    excluded_ports_from_var=$(normalize_ports "$excluded_ports_from_var")

    if [ -n "$excluded_ports_from_file" ]; then
        conflict_found=1
        display_ports=$(grep -v '^#' "$file_port_exclude" | grep -v '^$' | tr '\n' ',' | sed 's/,$//')
        error_message="${error_message} -> Ports found in file (${yellow}$file_port_exclude${reset}): ${yellow}$display_ports${reset}\n"
    fi

    if [ -n "$excluded_ports_from_var" ]; then
        conflict_found=1
        error_message="${error_message} -> The S99xkeen file specifies the exclusion ports: ${yellow}$excluded_ports_from_var${reset}\n"
    fi

    if [ "$conflict_found" -eq 1 ]; then
        echo -e "${red}Error${reset}: Cannot add proxy ports because exceptions are already set"
        echo -e "$error_message"
        echo -e "First clear all excluded ports, then try again"
        return 1
    fi

    ports=$(normalize_ports "$1")
    current_ports=$(
        awk -F= '/^port_donor/{print $2; exit}' $initd_dir/S99xkeen \
        | tr -d '"'
    )
    current_ports=${current_ports:-""}

    current_ports=$(echo "$current_ports" | sed 's/^,//')

    user_proxy_ports=""
    if [ -f "/opt/etc/xkeen/port_proxying.lst" ]; then
        user_proxy_ports=$(grep -v '^#' "/opt/etc/xkeen/port_proxying.lst" | grep -v '^$' | tr '\n' ',' | sed 's/,$//')
        user_proxy_ports=$(normalize_ports "$user_proxy_ports")
    fi

    all_current_ports="$current_ports"
    if [ -n "$user_proxy_ports" ] && [ -n "$all_current_ports" ]; then
        all_current_ports="$all_current_ports,$user_proxy_ports"
    elif [ -n "$user_proxy_ports" ]; then
        all_current_ports="$user_proxy_ports"
    fi

    if echo "$all_current_ports" | grep -qv "\(^\|,\)80\(,\|$\)"; then
        ports="80,$ports"
    fi
    if echo "$all_current_ports" | grep -qv "\(^\|,\)443\(,\|$\)"; then
        ports="443,$ports"
    fi

    ports=$(validate_and_clean_ports "$ports")

    # We connect the current ports with the transferred ones and remove duplicates
    new_ports=
    if [ -z "$current_ports" ]; then
        new_ports="$ports"
    else
        if [ -n "$ports" ]; then
            new_ports=$(echo "$current_ports,$ports" | tr ',' '\n' | sort -n -u | tr '\n' ',' | sed 's/,$//')
        else
            new_ports="$current_ports"
        fi
    fi

    added_ports=
    duplicate_ports=
    for port in $(echo "$ports" | tr ',' '\n'); do
        if ! echo "$current_ports" | tr ',' '\n' | grep -Fxq "$port"; then
            added_ports="$added_ports\n     $port"
        else
            duplicate_ports="$duplicate_ports\n     $port"
        fi
    done

    new_ports=$(echo $new_ports | sed 's/^ *//')

    # If new_ports is empty, do not add a comma
    if [ -n "$new_ports" ]; then
        port_var="port_donor=\"$new_ports\""
    else
        port_var="port_donor=\"\""
    fi

    tmpfile=$(mktemp)
    awk -v new="$port_var" 'BEGIN{replaced=0} /^port_donor/ && !replaced {sub(/^port_donor="[^"]*"/, new); replaced=1} {print}' $initd_dir/S99xkeen > "$tmpfile" && mv "$tmpfile" $initd_dir/S99xkeen

    while true; do
        if data_is_updated_donor "$initd_dir/S99xkeen" "$new_ports"; then break; fi
        sleep 1
    done

    if [ -z "$added_ports" ]; then
        echo -e "List of ports ${red}not updated${reset}\n Proxy client ${yellow}already running${reset} on ports$duplicate_ports"
    else
        echo -e "Port list ${green}successfully updated${reset}\n New proxy client ports$added_ports"
        if [ -n "$duplicate_ports" ]; then
            echo -e "Proxy client ${yellow} is already running ${reset} on ports $duplicate_ports"
        fi
    fi

    if [ -n "$missing_ports" ]; then
        echo -e "${red}Warning${reset}: Recommended ports (${yellow}${missing_ports}${reset}) are not added to proxying!"
    fi
}

dell_ports_donor() {
    ports=$(normalize_ports "$1")
    current_ports=$(
        awk -F= '/^port_donor/{print $2; exit}' "$initd_dir/S99xkeen" \
        | tr -d '"'
    )
    new_ports="$current_ports"
    deleted_ports=
    not_found_ports=

    if [ -z "$current_ports" ]; then
        echo -e "Proxy client runs on ${yellow}all${reset} ports\n ${red}No${reset} specific ports to remove"
        return
    fi

    if [ -z "$ports" ]; then
        new_ports=
        echo -e "All ${green}ports have been cleared successfully${reset}\n Proxy client is running on ${yellow}all${reset} ports"
    else
        for port in $(echo "$ports" | tr ',' '\n'); do
            if echo "$new_ports" \
                | tr ',' '\n' \
                | grep -Fxq "$port"; then
                new_ports=$(
                    echo "$new_ports" \
                    | tr ',' '\n' \
                    | grep -vFx "$port" \
                    | sort -n \
                    | tr '\n' ',' \
                    | sed 's/^,//; s/,$//'
                )
                deleted_ports="$deleted_ports\n     $port"
            else
                not_found_ports="$not_found_ports\n     $port"
            fi
        done
    fi

    new_ports=$(
        echo "$new_ports" \
        | sed 's/^ *//;s/ *,$//' | tr -d '\n'
    )

    # Removing commas after the last number in the new_ports variable before the closing quotes
    new_ports=$(echo "$new_ports" | sed 's/,\+$//')

    awk -v new_ports="$new_ports" -F= '
    BEGIN {OFS=FS; first=1}
    /^port_donor/ && first {
        if (new_ports == "") {
            print "port_donor=\"\""
			} else {
            print "port_donor=\"" new_ports "\""
        }
        first=0
        next
    }
    {print}' "$initd_dir/S99xkeen" > temp && mv temp "$initd_dir/S99xkeen"

    if [ -n "$ports" ]; then
        if [ -z "$deleted_ports" ]; then
            echo -e "List of ports ${red}not updated${reset}\n Proxy client ${yellow}does not work${reset} on ports$not_found_ports"
        else
            echo -e "Port list ${green}updated successfully${reset}\n Deleted ports$deleted_ports"
            if [ -n "$not_found_ports" ]; then
                echo -e "Proxy client ${yellow}doesn't work${reset} with ports$not_found_ports"
            fi
        fi
    fi
}

add_ports_exclude() {
    add_ports="exclude"
    choice_port_xkeen
    if [ -z "$1" ]; then
        echo -e "${red}Error${reset}: port list cannot be empty"
        return 1
    fi

    file_port_proxying="/opt/etc/xkeen/port_proxying.lst"
    donor_ports_from_file=""
    donor_ports_from_var=""
    conflict_found=0
    error_message=""

    if [ -f "$file_port_proxying" ]; then
        donor_ports_from_file=$(grep -v '^#' "$file_port_proxying" | grep -v '^$' | tr -d '[:space:]')
    fi

    donor_ports_from_var=$(
        awk -F= '/^port_donor/{print $2; exit}' "$initd_dir/S99xkeen" \
        | tr -d '"' | tr -d '[:space:]'
    )
    donor_ports_from_var=$(normalize_ports "$donor_ports_from_var")

    if [ -n "$donor_ports_from_file" ]; then
        conflict_found=1
        display_ports=$(grep -v '^#' "$file_port_proxying" | grep -v '^$' | tr '\n' ',' | sed 's/,$//')
        error_message="${error_message} -> Ports found in file (${yellow}$file_port_proxying${reset}): ${yellow}$display_ports${reset}\n"
    fi

    if [ -n "$donor_ports_from_var" ]; then
        conflict_found=1
        error_message="${error_message} -> The S99xkeen file specifies the proxy ports: ${yellow}$donor_ports_from_var${reset}\n"
    fi

    if [ "$conflict_found" -eq 1 ]; then
        echo -e "${red}Error${reset}: Cannot add excluded ports because proxy ports are already set"
        echo -e "$error_message"
        echo -e "First clear all proxy ports, then try again"
        return 1
    fi

    ports=$(normalize_ports "$1")
    current_ports=$(
        awk -F= '/^port_exclude/{print $2; exit}' $initd_dir/S99xkeen \
        | tr -d '"'
    )
    current_ports=${current_ports:-""}

    # Remove possible comma at the beginning
    current_ports=$(echo "$current_ports" | sed 's/^,//')

    # We connect the current ports with the transferred ones and remove duplicates
    new_ports=
    if [ -z "$current_ports" ]; then
        new_ports="$ports"
    else
        if [ -n "$ports" ]; then
            new_ports=$(echo "$current_ports,$ports" | tr ',' '\n' | sort -n -u | tr '\n' ',' | sed 's/,$//')
        else
            new_ports="$current_ports"
        fi
    fi

    added_ports=
    duplicate_ports=
    for port in $(echo "$ports" | tr ',' '\n'); do
        if ! echo "$current_ports" | tr ',' '\n' | grep -Fxq "$port"; then
            added_ports="$added_ports\n     $port"
        else
            duplicate_ports="$duplicate_ports\n     $port"
        fi
    done

    new_ports=$(echo $new_ports | sed 's/^ *//')

    # If new_ports is empty, do not add a comma
    if [ -n "$new_ports" ]; then
        port_var="port_exclude=\"$new_ports\""
    else
        port_var="port_exclude=\"\""
    fi

    tmpfile=$(mktemp)
    awk -v new="$port_var" 'BEGIN{replaced=0} /^port_exclude/ && !replaced {sub(/^port_exclude="[^"]*"/, new); replaced=1} {print}' $initd_dir/S99xkeen > "$tmpfile" && mv "$tmpfile" $initd_dir/S99xkeen

    while true; do
        if data_is_updated_excluded "$initd_dir/S99xkeen" "$new_ports"; then break; fi
        sleep 1
    done

    if [ -z "$added_ports" ]; then
        echo -e "${yellow}Warning${reset}"
		echo -e "The list of exception ports ${red}has not been updated${reset}\n The proxy client no longer works with ports$duplicate_ports"
    else
        echo -e "${green}Success${reset}"
		echo -e "List of exception ports ${green}successfully updated${reset}\n New ports with which the proxy client will not work$added_ports"
        if [ -n "$duplicate_ports" ]; then
            echo -e "${yellow}Error${reset}"
			echo -e "Proxy client ${yellow}no longer works${reset} with ports$duplicate_ports"
        fi
    fi
}

dell_ports_exclude() {
    ports=$(normalize_ports "$1")
    current_ports=$(
        awk -F= '/^port_exclude/{print $2; exit}' "$initd_dir/S99xkeen" \
        | tr -d '"'
    )
    new_ports="$current_ports"
    deleted_ports=
    not_found_ports=

    if [ -z "$current_ports" ]; then
        echo -e "Proxy client runs on ${yellow}all${reset} ports\n ${red}No${reset} specific ports to remove"
        return
    fi

    if [ -z "$ports" ]; then
        new_ports=
        echo -e "${green}Success${reset}"
        echo -e "All ports cleared\n Proxy client running on ${yellow}all${reset} ports"
    else
        for port in $(echo "$ports" | tr ',' '\n'); do
            if echo "$new_ports" \
                | tr ',' '\n' \
                | grep -Fxq "$port"; then
                new_ports=$(
                    echo "$new_ports" \
                    | tr ',' '\n' \
                    | grep -vFx "$port" \
                    | sort -n \
                    | tr '\n' ',' \
                    | sed 's/^,//; s/,$//'
                )
                deleted_ports="$deleted_ports\n     $port"
            else
                not_found_ports="$not_found_ports\n     $port"
            fi
        done
    fi

    new_ports=$(
        echo "$new_ports" \
        | sed 's/^ *//;s/ *,$//' | tr -d '\n'
    )

    # Removing commas after the last number in the new_ports variable before the closing quotes
    new_ports=$(echo "$new_ports" | sed 's/,\+$//')

    awk -v new_ports="$new_ports" -F= '
    BEGIN {OFS=FS; first=1}
    /^port_exclude/ && first {
        if (new_ports == "") {
            print "port_exclude=\"\""
        } else {
            print "port_exclude=\"" new_ports "\""
        }
        first=0
        next
    }
    {print}' "$initd_dir/S99xkeen" > temp && mv temp "$initd_dir/S99xkeen"

    if [ -n "$ports" ]; then
        if [ -z "$deleted_ports" ]; then
            echo -e "${yellow}Warning${reset}"
			echo -e "Exception port list ${red}not updated${reset}\n Proxy client has no excluded ports$not_found_ports"
        else
            echo -e "${green}Success${reset}"
			echo -e "The list of exclusion ports was successfully updated\n Deleted ports$deleted_ports"
            if [ -n "$not_found_ports" ]; then
                 echo -e "${yellow}Error${reset}"
				echo -e "Proxy client ${yellow}doesn't work${reset} with ports$not_found_ports"
            fi
        fi
    fi
}

# Get a list of proxy ports
get_ports_donor() {
    port_donor=$(grep -m1 '^port_donor=' $initd_dir/S99xkeen | cut -d'=' -f2 | tr -d '"')
    port_exclude=$(grep -m1 '^port_exclude=' $initd_dir/S99xkeen | cut -d'=' -f2 | tr -d '"')
    
    process_user_ports
    
    if [ -z "$port_donor" ] || [ "$port_donor" = "" ]; then
        echo -e "Proxy client running ${yellow}on all ports${reset}"
    else
        formatted_ports=$(echo "$port_donor" | tr ',' '\n' | sed 's/^/     /')
        echo -e "Proxy client running on ports\n${green}$formatted_ports${reset}"
    fi
}

# Get a list of ports excluded from proxying
get_ports_exclude() {
    port_donor=$(grep -m1 '^port_donor=' $initd_dir/S99xkeen | cut -d'=' -f2 | tr -d '"')
    port_exclude=$(grep -m1 '^port_exclude=' $initd_dir/S99xkeen | cut -d'=' -f2 | tr -d '"')
    
    process_user_ports
    
    if [ -z "$port_exclude" ] || [ "$port_exclude" = "" ]; then
        echo -e "${yellow}No ports${reset} excluded from proxying"
    else
        formatted_ports=$(echo "$port_exclude" | tr ',' '\n' | sed 's/^/     /')
        echo -e "Ports excluded from proxying\n${green}$formatted_ports${reset}"
    fi
}
